from django.db import models

# Create your models here.
class Seller(models.Model):
    sname=models.CharField(max_length=64)
    sphonenumber=models.IntegerField()
    scropname=models.CharField(max_length=64)
    scropcost=models.FloatField()
    saddress=models.CharField(max_length=100)
    sdescription=models.CharField(max_length=100)

    class Meta:
        unique_together = (('sphonenumber', 'scropname'),)


class Buyer(models.Model):
    bname=models.CharField(max_length=64)
    bphonenumber=models.IntegerField()
    bcropname=models.CharField(max_length=64)
    bcropcost=models.FloatField()
    baddress=models.CharField(max_length=100)
    bdescription=models.CharField(max_length=100)

    class Meta:
        unique_together = (('bphonenumber', 'bcropname'),)
