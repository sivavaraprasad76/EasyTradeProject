from django.contrib import admin
from testapp.models import Seller,Buyer
# Register your models here.

class SellerAdmin(admin.ModelAdmin):

    list_display=['sname','sphonenumber','scropname','scropcost','saddress','sdescription']

class BuyerAdmin(admin.ModelAdmin):

    list_display=['bname','bphonenumber','bcropname','bcropcost','baddress','bdescription']


admin.site.register(Seller,SellerAdmin)
admin.site.register(Buyer,BuyerAdmin)
