from django.shortcuts import render
from testapp.models import Seller,Buyer
from django.conf import settings
from django.core.mail import send_mail
import random

# Create your views here.
def Homepage(request):
    seller=Seller.objects.all()
    buyer=Buyer.objects.all()
    Homepage.bcropname=None
    Homepage.scropname=None
    print("1")
    if request.method=="POST":
        Homepage.scropname=request.POST["cropname"]
        Homepage.bcropname=request.POST["cropname"]
        print(Homepage.scropname)
        print(Homepage.bcropname)
        print("2")
    return render(request,'testapp/homepage.html',{'seller':seller,'buyer':buyer})

def about(request):
    return render(request,'testapp/about.html',)

def search(request):
    buyer1=Buyer.objects.filter(bcropname__iexact=Homepage.bcropname)
    print(Homepage.scropname)
    print(Homepage.bcropname)
    seller1=Seller.objects.filter(scropname__iexact=Homepage.scropname)
    print("3")
    print(seller1,buyer1)
    print("4")
    return render(request,'testapp/search.html',{'seller1':seller1,'buyer1':buyer1})

def gmail(request):
    if request.method=="POST":
        print("1")
        gmail.gmail=request.POST["gmail"]
        print(gmail)
        gmail.number = random.randint(1111,9999)
        subject = 'YOUR OTP'
        message = str(gmail.number)
        email_from = settings.EMAIL_HOST_USER
        send_mail( subject, message, email_from, [gmail.gmail] )
        print("email sent")
    return render(request,'testapp/gmail.html')

def otp(request):
    message=None
    if request.method=="POST":
        print("2")
        otp.otp=request.POST["otp"]
        try:

            print(otp.otp,gmail.number,gmail.gmail)
            num1=int(otp.otp)
            num2=int(gmail.number)
            if num1 == num2:
                print("inside OTP")
                message="S"
        except:
            pass

    return render(request,'testapp/otp.html',{'message':message})


def Bregistration(request):
    Bregistration.x=9999
    value=None
    if request.method=="POST":
        bname=request.POST["bname"]
        bphonenumber=request.POST["bphonenumber"]
        bcropname=request.POST["bcropname"]
        print("in the middle")
        bcropcost=request.POST["bcropcost"]
        baddress=request.POST["baddress"]
        bdescription=request.POST["bdescription"]

        try:
            info=Buyer(bname=bname,bphonenumber=bphonenumber,bcropname=bcropname,bcropcost=bcropcost,baddress=baddress,bdescription=bdescription)
            info.save()
            value=None
        except:
            value=1

    return render(request,'testapp/bregistration.html',{'message':value})

def bdisplay(request):
    bdisplay.bphonenumber=1
    bdisplay.bcropname=1
    if request.method=="POST":
        bdisplay.bphonenumber=request.POST["bphonenumber"]
        bdisplay.bcropname=request.POST["bcropname"]
    bdisplay.buyer=Buyer.objects.filter(bphonenumber=bdisplay.bphonenumber,bcropname__icontains=bdisplay.bcropname)
    return render(request,'testapp/bdisplay.html',{'buyer':bdisplay.buyer})

def bdelete(request):
    try:
        bdisplay.buyer.delete()
    except:
        pass
    return render(request,'testapp/bdelete.html')

def bupdate(request):
    message=None
    if request.method=="POST":
        bupdate.bcropcost=request.POST["bcropcost"]
        pass
    try:
        bdisplay.buyer.update(bcropcost=bupdate.bcropcost)
        message="updated"
    except:
        pass
    return render(request,'testapp/bupdate.html')





def gmail2(request):
    if request.method=="POST":
        print("1")
        gmail2.gmail=request.POST["gmail"]
        print(gmail)
        gmail2.number = random.randint(1111,9999)
        subject = 'YOUR OTP'
        message = str(gmail2.number)
        email_from = settings.EMAIL_HOST_USER
        send_mail( subject, message, email_from, [gmail2.gmail] )
        print("email sent")
    return render(request,'testapp/gmail2.html')

def otp2(request):
    message=None
    if request.method=="POST":
        print("2")
        otp2.otp=request.POST["otp"]
        try:
            print(otp2.otp,gmail2.number,gmail2.gmail)
            num1=int(otp2.otp)
            num2=int(gmail2.number)
            if num1 == num2:
                print("inside OTP")
                message="S"
        except:
            pass
    return render(request,'testapp/otp2.html',{'message':message})


def Sregistration(request):
    print("en")
    value=None
    tag=None
    if request.method=="POST":
        print("1")
        print("at start")
        sname=request.POST["sname"]
        sphonenumber=request.POST["sphonenumber"]
        scropname=request.POST["scropname"]
        print("in the middle")
        scropcost=request.POST["scropcost"]
        saddress=request.POST["saddress"]
        sdescription=request.POST["sdescription"]
        try:
            info=Seller(sname=sname,sphonenumber=sphonenumber,scropname=scropname,scropcost=scropcost,saddress=saddress,sdescription=sdescription)
            info.save()
            value=None
        except:
            value=1

    return render(request,'testapp/sregistration.html',{'message':value})

def sdisplay(request):
    sdisplay.sphonenumber=1
    sdisplay.scropname=1
    if request.method=="POST":
        sdisplay.sphonenumber=request.POST["sphonenumber"]
        sdisplay.scropname=request.POST["scropname"]
    sdisplay.seller=Seller.objects.filter(sphonenumber=sdisplay.sphonenumber,scropname__icontains=sdisplay.scropname)
    return render(request,'testapp/sdisplay.html',{'seller':sdisplay.seller})

def sdelete(request):
    try:
        sdisplay.seller.delete()
    except:
        pass
    return render(request,'testapp/sdelete.html')

def supdate(request):
    message=None
    if request.method=="POST":
        supdate.scropcost=request.POST["scropcost"]
        pass
    try:
        sdisplay.seller.update(scropcost=supdate.scropcost)
        message="updated"
    except:
        pass
    return render(request,'testapp/supdate.html')
